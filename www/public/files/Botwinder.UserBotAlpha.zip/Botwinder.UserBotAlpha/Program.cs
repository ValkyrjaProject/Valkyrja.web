﻿using System;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
using Discord;

namespace Botwinder.UserBot
{
	public class Sandbox
	{
#pragma warning disable 1998
		async public static Task<object> CodeTest(CommandArguments e)
		{
			//Your code here.
			return "Done!";
		}
#pragma warning restore 1998
	}


	public class CommandArguments
	{
		/// <summary> True if the commands was executed in the Private Message and False if it was text channel. </summary>
		public bool IsPm { get; private set; }

		/// <summary> Message, where the command was invoked. </summary>
		public Message Message { get; private set; }

		/// <summary> Text of the Message, where the command was invoked. The command itself is excluded. </summary>
		public string TrimmedMessage { get; private set; }

		/// <summary> Command parameters (individual words) from the original message. MessageArgs[0] == Command.ID; </summary>
		public string[] MessageArgs { get; private set; }
	}
}
